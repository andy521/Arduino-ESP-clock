arduino nano 旧版 bootloader 的波特率是57600
在用ESP8266给它下载时需要更改 ESP combine 固件中的波特率到 57600

—————————
ESP	ADO
TX 	RX
RX 	TX
D4	RST
——————————
OLED	ESP8266
Vin	3.3V
GND	GND
SCL	GPIO 5 (D1)
SDA	GPIO 4 (D2)
——————————
TX_LED	GPIO13
RX_LED	GPIO15
WIFI_LED	GPIO14
——————————
If you're using an OLED display with SPI communication protocol, 
use the following GPIOs.
—————————
OLED	ESP8266
CLK	GPIO 14
MISO	GPIO 12
MOSI	GPIO 13
CS	GPIO 15